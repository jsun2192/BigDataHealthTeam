MIMIC CET trainer — setup and usage
===================================

Contents:
  train_mimic_cet.py          New training/evaluation script
  cet.py                      Exactly the uploaded model file (unchanged)
  mimic_adapter_v2.py         Adapter from previously created v2 starter
  example_load_and_censor.py Censoring code from v2 starter
  test_train_mimic_cet.py     Five additional unit tests

To use with your existing v2 demo folder:

1. Copy train_mimic_cet.py and cet.py into cet_mimic_demo_starter_v2/.
   The original v2 folder should already contain mimic_adapter_v2.py and
   example_load_and_censor.py. These Python modules need to be in the same
   directory as the trainer or importable on PYTHONPATH.

2. Activate the Python environment in which you ran v2 preprocessing.
   Install missing packages if necessary:
     python -m pip install torch numpy scikit-learn pytest
   For exact paper-style concordance, also install:
     python -m pip install lifelines

3. Confirm processed_demo/mimic_demo_features.npz exists, then run:
     python train_mimic_cet.py --npz processed_demo/mimic_demo_features.npz --n-hidden 64 --n-samples 10 --batch-size 32 --max-epochs 30 --seeds 0 --out results_mimic_demo --verbose

4. View results_mimic_demo/summary.txt and metrics.json.
   It also writes CET checkpoints and test predictions for the run.

5. Optional verification:
     python -m pytest -q test_train_mimic_cet.py

6. For future full authorized MIMIC data, consider:
     python train_mimic_cet.py --npz processed_full/mimic_demo_features.npz --n-hidden 750 --n-samples 100 --seeds 0 1 2 --out results_mimic_full

Important:
- Train/validation/test assignment comes from the existing NPZ. Do not re-split.
- Censoring medians come from training only and are held fixed by default.
- The hidden c_true array is used only for occurrence evaluation, not fitting.
- The supplied fit_cet trains on CPU and does not automatically use the RTX 4090.
- Time predictions are generated as median(exp(mu)) over stochastic samples,
  without forcing each target event to occur.
- AUC may be undefined with a small demo/test split lacking both classes.
- The v2 data protocol differs in documented ways from the authors' original
  features, event origin and inclusion criteria. Demo scores are not a paper
  replication and must not be treated as one.
- For restricted MIMIC data, keep checkpoint/prediction files in the approved
  environment. Do not upload patient-level results or pretrained model files.
- The uploaded summarize.py will NOT work directly: it expects five XGBoost
  arms (A/B/C/D/O), whereas this trainer runs only A_cet. Use the provided
  summary.txt/metrics.json instead.
