#!/usr/bin/env python3
"""Create first-24h admission-level MIMIC-III demo features for CET experiments.

This is a reproducible DEMO preprocessing implementation, not an exact recovery
of the paper's unpublished selected ITEMID dictionary. Default chart types follow
TRAIN-set VALUENUM nonmissing fractions; the resulting feature dimension can differ
from 346. The optional --chart-numeric-count 42 forces the paper-implied 42/38
split only as a diagnostic sensitivity experiment. The exact ranking unit
(raw rows versus admission prevalence) was not published.

Use only on machines/environments where your MIMIC-III use is authorized. Do not
upload restricted full MIMIC patient-level data/derived rows into a chat.
"""
from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit

LOG = logging.getLogger("mimic_features")

# Match exact D_LABITEMS LABEL strings (case-insensitive) rather than selecting by ITEMID range.
# Multiple ITEMIDs may map to the same label (e.g., D-Dimer).
ALL_TARGETS = {
    "WBC, CSF": ("wbc, csf",),
    "Troponin T": ("troponin t",),
    "Intubated": ("intubated",),
    "WBC, Pleural": ("wbc, pleural",),
    "TSH": ("thyroid stimulating hormone",),
    "D-Dimer": ("d-dimer",),
    "Urobilinogen": ("urobilinogen",),
    "ANA": ("anti-nuclear antibody",),
    "Ammonia": ("ammonia",),
    "Lipase": ("lipase",),
}
DEFAULT_TARGETS = ("D-Dimer", "TSH", "Troponin T", "Urobilinogen")
# Backward-compatible alias for older tests.
TARGETS = {name: ALL_TARGETS[name] for name in DEFAULT_TARGETS}


def csv_path(root: Path, stem: str) -> Path:
    for filename in (f"{stem}.csv", f"{stem}.csv.gz"):
        path = root / filename
        if path.exists():
            return path
    raise FileNotFoundError(f"Expected {stem}.csv or {stem}.csv.gz in {root}")


def read_table(root: Path, name: str, cols: list[str], parse_dates=()) -> pd.DataFrame:
    return pd.read_csv(csv_path(root, name), usecols=cols,
                       parse_dates=list(parse_dates), low_memory=False)


def find_target_ids(d_labitems: pd.DataFrame, target_names=None) -> dict[str, list[int]]:
    names = d_labitems["label"].fillna("").astype(str).str.strip().str.casefold()
    result = {}
    names_to_match = DEFAULT_TARGETS if target_names is None else target_names
    for target in names_to_match:
        aliases = ALL_TARGETS[target]
        ids = d_labitems.loc[names.isin(aliases), "itemid"].astype(int).tolist()
        if not ids:
            raise ValueError(f"No D_LABITEMS item ID for {target}; inspect labels")
        result[target] = sorted(ids)
    return result


def make_cohort(admissions: pd.DataFrame, icustays: pd.DataFrame, seed: int) -> pd.DataFrame:
    """One row per hospital admission with an ICU stay and 24 h follow-up."""
    icu_hadm = icustays["hadm_id"].dropna().astype(int).unique()
    a = admissions.loc[admissions["hadm_id"].isin(icu_hadm),
                       ["subject_id", "hadm_id", "admittime", "dischtime"]].copy()
    a = a.dropna(subset=["subject_id", "hadm_id", "admittime", "dischtime"])
    a["landmark"] = a["admittime"] + pd.Timedelta(hours=24)
    a = a.loc[a["dischtime"] >= a["landmark"]].copy()
    a = a.drop_duplicates(subset=["hadm_id"]).sort_values("hadm_id").reset_index(drop=True)
    if len(a) < 5 or a["subject_id"].nunique() < 5:
        raise ValueError("Too few eligible admissions/patients to split")

    ix = np.arange(len(a))
    splitter = GroupShuffleSplit(n_splits=1, train_size=0.6, random_state=seed)
    train_ix, rest_ix = next(splitter.split(ix, groups=a["subject_id"]))
    second = GroupShuffleSplit(n_splits=1, train_size=0.5, random_state=seed + 1)
    val_local, test_local = next(second.split(rest_ix, groups=a.iloc[rest_ix]["subject_id"]))
    a["split"] = ""
    a.loc[train_ix, "split"] = "train"
    a.loc[rest_ix[val_local], "split"] = "val"
    a.loc[rest_ix[test_local], "split"] = "test"
    if a.groupby("subject_id")["split"].nunique().max() != 1:
        raise AssertionError("Subject leakage across train/val/test")
    return a


def admission_events(events: pd.DataFrame, cohort: pd.DataFrame,
                     *, first24: bool) -> pd.DataFrame:
    """Strictly associate events via HADM_ID; do not guess missing LABEVENTS HADM_ID."""
    events = events.dropna(subset=["hadm_id", "charttime", "itemid"])
    events = events.merge(cohort[["hadm_id", "admittime", "dischtime", "landmark", "split"]],
                          on="hadm_id", how="inner", validate="many_to_one")
    upper = events["landmark"] if first24 else events["dischtime"]
    return events.loc[(events["charttime"] >= events["admittime"]) &
                      (events["charttime"] < upper if first24
                       else events["charttime"] <= upper)].copy()


def top_ids(events: pd.DataFrame, cohort: pd.DataFrame, k: int,
            exclude: set[int] | None = None, rank_by: str = "rows") -> list[int]:
    """Select frequent ITEMIDs using TRAIN rows only.

    `rows` = raw record frequency (default hypothesis for 'most common');
    `admissions` = number of unique training admissions with the item.
    The authors did not publish their frequency denominator.
    """
    tr = events.loc[events["split"] == "train"]
    if exclude:
        tr = tr.loc[~tr["itemid"].isin(exclude)]
    if rank_by == "rows":
        counts = tr.groupby("itemid").size().rename("frequency")
    elif rank_by == "admissions":
        counts = tr[["hadm_id", "itemid"]].drop_duplicates().groupby("itemid").size().rename("frequency")
    else:
        raise ValueError(f"Unrecognized frequency unit: {rank_by}")
    rank = counts.reset_index().sort_values(["frequency", "itemid"], ascending=[False, True])
    ids = rank["itemid"].astype(int).head(k).tolist()
    if len(ids) < k:
        LOG.warning("Only %d eligible ITEMIDs for top %d in the demo", len(ids), k)
    return ids


def item_frequencies(events: pd.DataFrame, selected: list[int], rank_by: str) -> pd.DataFrame:
    """Audit exact counts, prevalence, and ranks for selected train ITEMIDs."""
    tr = events.loc[events["split"] == "train"]
    rows = tr.groupby("itemid").size().rename("n_rows")
    admissions = tr[["hadm_id", "itemid"]].drop_duplicates().groupby("itemid").size().rename("n_admissions")
    out = pd.concat([rows, admissions], axis=1).fillna(0).astype(int).reset_index()
    out["selected"] = out["itemid"].isin(selected)
    out = out.sort_values(["n_rows" if rank_by == "rows" else "n_admissions", "itemid"],
                          ascending=[False, True]).reset_index(drop=True)
    out["rank"] = np.arange(1, len(out) + 1)
    return out


def chart_types(chart24: pd.DataFrame, ids: list[int], n_numeric: int) -> tuple[list[int], list[int], pd.DataFrame]:
    """Infer numeric fraction on TRAIN, or force N numeric items for paper shape."""
    tr = chart24[(chart24["split"] == "train") & chart24["itemid"].isin(ids)].copy()
    tr["numerical"] = tr["valuenum"].notna()
    rates = tr.groupby("itemid")["numerical"].agg(["mean", "size"]).reset_index()
    rates = pd.DataFrame({"itemid": ids}).merge(rates, on="itemid", how="left")
    rates["mean"] = rates["mean"].fillna(0)
    rates["size"] = rates["size"].fillna(0)
    rates = rates.sort_values(["mean", "size", "itemid"], ascending=[False, False, True])
    if n_numeric >= 0:
        if n_numeric > len(ids):
            raise ValueError("Requested numeric chart count exceeds selected chart items")
        numeric = rates["itemid"].head(n_numeric).astype(int).tolist()
    else:
        numeric = rates.loc[rates["mean"] >= 0.8, "itemid"].astype(int).tolist()
    categorical = sorted(set(ids) - set(numeric))
    return sorted(numeric), categorical, rates


def make_features(cohort: pd.DataFrame, chart24: pd.DataFrame,
                  lab24: pd.DataFrame, output24: pd.DataFrame,
                  chart_num: list[int], chart_cat: list[int],
                  labids: list[int], outputids: list[int],
                  categorical_count_mode: str = "value") -> pd.DataFrame:
    """Construct raw, unstandardized features; preserve NaNs for missing summary stats."""
    idx = pd.Index(cohort["hadm_id"].to_numpy(), name="hadm_id")
    blocks: list[pd.DataFrame] = []

    def numeric_block(data: pd.DataFrame, ids: list[int], prefix: str,
                      stats: tuple[str, ...]) -> None:
        sub = data.loc[data["itemid"].isin(ids)].copy()
        # count means number of valid numeric values (not categorical records).
        grouped = sub.groupby(["hadm_id", "itemid"])["valuenum"].agg(list(stats))
        for stat in stats:
            if grouped.empty:
                mat = pd.DataFrame(index=idx, columns=ids, dtype=float)
            else:
                mat = grouped[stat].unstack("itemid").reindex(index=idx, columns=ids)
            mat.columns = [f"{prefix}_{stat}_{int(itemid)}" for itemid in ids]
            blocks.append(mat)

    numeric_block(chart24, chart_num, "chart", ("count", "mean", "min", "max"))
    cat = chart24.loc[chart24["itemid"].isin(chart_cat)].copy()
    # Corrected default: count recorded categorical VALUE strings rather than
    # VALUENUM, which is null for many clinically meaningful categorical items.
    # The original authors' create_features() always uses VALUENUM, even for the
    # nonnumeric group. That can yield all-zero counts for categorical items.
    if categorical_count_mode == "value":
        cat["value"] = cat["value"].astype("string").str.strip().replace("", pd.NA)
        count_column = "value"
    elif categorical_count_mode == "valuenum":
        count_column = "valuenum"
    else:
        raise ValueError(categorical_count_mode)
    cnt = cat.groupby(["hadm_id", "itemid"])[count_column].count().unstack("itemid")
    cnt = cnt.reindex(index=idx, columns=chart_cat)
    cnt.columns = [f"chart_count_{int(i)}" for i in chart_cat]
    blocks.append(cnt)

    numeric_block(lab24, labids, "lab", ("count", "mean", "min", "max"))
    numeric_block(output24, outputids, "output", ("count", "sum"))
    raw = pd.concat(blocks, axis=1).astype(float)
    # Missing observation counts/totals genuinely mean zero. Summaries are imputed on train.
    is_zero = [col for col in raw if col.startswith("output_") or "_count_" in col]
    raw[is_zero] = raw[is_zero].fillna(0)
    raw.index.name = "hadm_id"
    if raw.columns.duplicated().any():
        raise AssertionError("Duplicate engineered feature names")
    return raw


def fit_transform_features(raw: pd.DataFrame, cohort: pd.DataFrame):
    """Fit imputation + z-score strictly on TRAIN; return model-ready float32 X."""
    train_ids = cohort.loc[cohort["split"] == "train", "hadm_id"]
    train = raw.loc[train_ids]
    medians = train.median(axis=0, skipna=True).fillna(0.0)
    imputed = raw.fillna(medians).fillna(0)
    mu = imputed.loc[train_ids].mean(axis=0)
    sigma = imputed.loc[train_ids].std(axis=0, ddof=0).replace(0, 1).fillna(1)
    x = ((imputed - mu) / sigma).to_numpy(dtype=np.float32)
    if not np.isfinite(x).all():
        raise ValueError("Feature matrix includes non-finite values")
    transform = {"feature_names": list(raw.columns),
                 "median": medians.to_dict(), "mean": mu.to_dict(), "std": sigma.to_dict()}
    return x, transform


def first_target_times(labs: pd.DataFrame, cohort: pd.DataFrame,
                       target_ids: dict[str, list[int]], outcome_start: str):
    """Return event times in hours, np.inf for no recorded post-landmark event."""
    eligible = admission_events(labs, cohort, first24=False)
    if outcome_start == "landmark":
        eligible = eligible.loc[eligible["charttime"] >= eligible["landmark"]].copy()
        baseline_col = "landmark"
    else:
        baseline_col = "admittime"
    labels = list(target_ids)
    times = np.full((len(cohort), len(labels)), np.inf, dtype=np.float64)
    cohort_hadm = cohort["hadm_id"].to_numpy()
    for j, lab in enumerate(labels):
        observed = eligible.loc[eligible["itemid"].isin(target_ids[lab])]
        first = observed.groupby("hadm_id")["charttime"].min()
        starts = cohort.set_index("hadm_id")[baseline_col]
        aligned = first.reindex(cohort_hadm)
        hours = (aligned.to_numpy() - starts.reindex(cohort_hadm).to_numpy()) / np.timedelta64(1, "h")
        hours = np.asarray(hours, dtype=float)
        valid = np.isfinite(hours) & (hours >= 0)
        times[valid, j] = hours[valid]
    return times.astype(np.float32), labels


def run(args: argparse.Namespace) -> dict:
    root, out = Path(args.input), Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    admission = read_table(root, "ADMISSIONS", ["subject_id", "hadm_id", "admittime", "dischtime"],
                           parse_dates=["admittime", "dischtime"])
    icu = read_table(root, "ICUSTAYS", ["subject_id", "hadm_id", "icustay_id"])
    d_lab = read_table(root, "D_LABITEMS", ["itemid", "label", "fluid"])
    d_item = read_table(root, "D_ITEMS", ["itemid", "label", "linksto"])
    cohort = make_cohort(admission, icu, args.seed)
    # Exclude all 10 target label families from inputs, even when modeling only four.
    all_target_ids = find_target_ids(d_lab, tuple(ALL_TARGETS))
    targets_to_model = tuple(ALL_TARGETS) if args.all_ten_targets else DEFAULT_TARGETS
    target_ids = {name: all_target_ids[name] for name in targets_to_model}
    excluded = {i for values in all_target_ids.values() for i in values}
    LOG.info("Cohort: %s eligible admissions, %s patients", len(cohort), cohort.subject_id.nunique())

    chart = read_table(root, "CHARTEVENTS", ["hadm_id", "itemid", "charttime", "value", "valuenum", "error"],
                       parse_dates=["charttime"])
    chart = chart.loc[chart["error"].fillna(0) != 1].drop(columns="error")
    chart["valuenum"] = pd.to_numeric(chart["valuenum"], errors="coerce")
    chart24 = admission_events(chart, cohort, first24=True)
    del chart

    labs = read_table(root, "LABEVENTS", ["hadm_id", "itemid", "charttime", "value", "valuenum"],
                      parse_dates=["charttime"])
    missing_hadm = int(labs["hadm_id"].isna().sum())
    labs["valuenum"] = pd.to_numeric(labs["valuenum"], errors="coerce")
    lab24 = admission_events(labs, cohort, first24=True)

    output = read_table(root, "OUTPUTEVENTS", ["hadm_id", "itemid", "charttime", "value", "iserror"],
                        parse_dates=["charttime"])
    output = output.loc[output["iserror"].fillna(0) != 1].drop(columns="iserror")
    output["valuenum"] = pd.to_numeric(output["value"], errors="coerce")
    output24 = admission_events(output, cohort, first24=True)
    del output

    chartids = top_ids(chart24, cohort, 80, rank_by=args.rank_by)
    labids = top_ids(lab24, cohort, 30, exclude=excluded, rank_by=args.rank_by)
    outputids = top_ids(output24, cohort, 10, rank_by=args.rank_by)
    num_chart, cat_chart, type_rates = chart_types(chart24, chartids, args.chart_numeric_count)
    LOG.info("Selected %d chart numeric, %d chart categorical, %d lab, %d output IDs",
             len(num_chart), len(cat_chart), len(labids), len(outputids))
    raw = make_features(cohort, chart24, lab24, output24,
                        num_chart, cat_chart, labids, outputids,
                        categorical_count_mode=args.categorical_count_mode)
    X, transform = fit_transform_features(raw, cohort)
    event_time, targets = first_target_times(labs, cohort, target_ids, args.outcome_start)
    c_true = np.isfinite(event_time).astype(np.float32)
    if not set(labids).isdisjoint(excluded):
        raise AssertionError("Target leakage: a target lab ITEMID is also a feature")

    np.savez_compressed(out / "mimic_demo_features.npz", x=X, event_time=event_time,
                        c_true=c_true, hadm_id=cohort["hadm_id"].to_numpy(),
                        subject_id=cohort["subject_id"].to_numpy(),
                        split=cohort["split"].astype(str).to_numpy(dtype=str),
                        feature_names=np.array(list(raw.columns)),
                        target_names=np.array(targets))
    raw.to_csv(out / "features_raw.csv.gz", compression="gzip")
    cohort.to_csv(out / "cohort.csv", index=False)
    (out / "feature_transform.json").write_text(json.dumps(transform, indent=2))

    dictlabels = dict(zip(d_item["itemid"].astype(int), d_item["label"].astype(str)))
    dictlabels.update(zip(d_lab["itemid"].astype(int), d_lab["label"].astype(str)))
    items = []
    for group_name, ids in (("chart_numeric", num_chart), ("chart_categorical", cat_chart),
                            ("lab_numeric", labids), ("output_numeric", outputids)):
        for itemid in ids:
            items.append({"group": group_name, "itemid": itemid,
                          "label": dictlabels.get(itemid, "UNKNOWN")})
    pd.DataFrame(items).to_csv(out / "selected_items.csv", index=False)
    type_rates.to_csv(out / "chart_numeric_rates.csv", index=False)
    audit_blocks = []
    for source, df, ids in (("chart", chart24, chartids), ("lab", lab24, labids),
                            ("output", output24, outputids)):
        block = item_frequencies(df, ids, args.rank_by)
        block.insert(0, "source", source)
        audit_blocks.append(block)
    pd.concat(audit_blocks, ignore_index=True).to_csv(out / "frequency_audit.csv", index=False)
    (out / "selected_itemid_groups.json").write_text(json.dumps({
        "chartevents_numeric": num_chart,
        "chartevents_nonnumeric": cat_chart,
        "labevents": labids,
        "outputevents": outputids
    }, indent=2))
    stats = {"n_admissions": len(cohort), "n_subjects": int(cohort.subject_id.nunique()),
             "split_admissions": cohort["split"].value_counts().to_dict(),
             "n_features": int(X.shape[1]), "n_chart_numeric": len(num_chart),
             "n_chart_categorical": len(cat_chart), "n_lab_items": len(labids),
             "n_output_items": len(outputids), "target_itemids": target_ids,
             "all_target_itemids_excluded": all_target_ids,
             "selection_frequency": args.rank_by,
             "categorical_count_mode": args.categorical_count_mode,
             "chart_numeric_type_threshold": (None if args.chart_numeric_count >= 0 else 0.8),
             "forced_chart_numeric_count": (args.chart_numeric_count if args.chart_numeric_count >= 0 else None),
             "outcome_start": args.outcome_start,
             "missing_hadm_id_lab_rows_excluded": missing_hadm,
             "outcome_counts": {name: int(c_true[:, j].sum()) for j, name in enumerate(targets)},
             "n_nan_after_scaling": int((~np.isfinite(X)).sum()),
             "note": "Feature selection reconstructs, but does not recover, authors' ITEMID list. "
                     "Admission outcome mode is a reproduction-oriented approximation. "
                     "Landmark mode predicts first record AFTER 24h, not necessarily first EVER record."}
    (out / "metadata.json").write_text(json.dumps(stats, indent=2))
    print(json.dumps(stats, indent=2))
    return stats


def parse_args():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", required=True, help="Folder containing MIMIC-III CSVs")
    ap.add_argument("--output", default="processed_demo")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--outcome-start", choices=["landmark", "admission"], default="admission",
                    help="admission is the reproduction-oriented approximate time origin; landmark tests AFTER 24h")
    ap.add_argument("--rank-by", choices=["rows", "admissions"], default="rows",
                    help="Frequency denominator for common-item selection (not specified by authors)")
    ap.add_argument("--categorical-count-mode", choices=["value", "valuenum"], default="value",
                    help="value=clinically meaningful nonmissing categorical counts; valuenum=original code behavior")
    ap.add_argument("--chart-numeric-count", type=int, default=-1,
                    help="-1=infer from >=80%% numeric; 42 forces original-paper-implied chart split")
    ap.add_argument("--all-ten-targets", action="store_true", help="Create all 10 paper outputs instead of four")
    ap.add_argument("--log-level", default="INFO")
    return ap.parse_args()


if __name__ == "__main__":
    args = parse_args()
    logging.basicConfig(level=getattr(logging, args.log_level.upper()),
                        format="%(levelname)s: %(message)s")
    run(args)
