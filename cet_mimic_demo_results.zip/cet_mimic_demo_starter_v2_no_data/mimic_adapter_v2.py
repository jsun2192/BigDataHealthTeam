"""Bridge the revised feature-engineering `.npz` to a CET/ET/BC training loop.

Unlike the original ad hoc mimic_adapter.py, this module:
- uses the `event_time` origin recorded in the feature pipeline metadata;
- estimates censoring medians using training rows only;
- keeps uncensored `c_true` separate from model inputs;
- uses fixed random seeds for reproducibility.

The full MIMIC-III data must remain on an authorized local machine.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from example_load_and_censor import censor_from_training_medians


def load_reconstruction(npz_path: str | Path, factor: float = 2.0, seed: int = 42):
    """Load a demo/full preprocessing output as a dictionary of aligned arrays.

    Keys: `x`, `t`, `s`, `c_true`, `event_time`, `split`, `target_names`,
    `feature_names`, `subject_id`, `hadm_id`, and `censor_medians`.

    Train the CET/ET/BC models using only x, t, and s, never c_true.
    Evaluate occurrence AUC using c_true *after training*.
    """
    with np.load(npz_path, allow_pickle=False) as d:
        data = {name: d[name].copy() for name in d.files}
    t, s, medians = censor_from_training_medians(
        data["event_time"], data["split"], factor=factor, seed=seed
    )
    data["t"] = t
    data["s"] = s
    data["censor_medians"] = medians
    return data


def split_model_inputs(data: dict, part: str):
    """Return model inputs (x, t, s), with truth deliberately excluded."""
    if part not in {"train", "val", "test"}:
        raise ValueError("part must be train, val, or test")
    mask = data["split"] == part
    return data["x"][mask], data["t"][mask], data["s"][mask]


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--npz", default="processed_demo/mimic_demo_features.npz")
    args = parser.parse_args()
    d = load_reconstruction(args.npz)
    print("X shape:", d["x"].shape)
    print("Target names:", list(d["target_names"]))
    for part in ["train", "val", "test"]:
        X, t, s = split_model_inputs(d, part)
        print(part, X.shape, t.shape, s.shape)
