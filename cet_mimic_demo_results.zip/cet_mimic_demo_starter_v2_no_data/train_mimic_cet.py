"""Train the uploaded PyTorch CET implementation on MIMIC-III demo/full features.

Designed for the files supplied in this conversation:
    - cet.py                         (CET + fit_cet)
    - mimic_adapter_v2.py            (load_reconstruction, split_model_inputs)
    - example_load_and_censor.py     (censor_from_training_medians)
    - processed_demo/mimic_demo_features.npz

The artificial censoring and patient-grouped splits are already defined by the
v2 preprocessing pipeline. Only (x, t, s) go into CET training. The *hidden*
true occurrence labels c_true are reserved for evaluation.

Example, from a directory containing these three .py modules:
    python train_mimic_cet.py --npz processed_demo/mimic_demo_features.npz \\
        --n-hidden 64 --n-samples 10 --batch-size 32 --max-epochs 30 \\
        --seeds 0 --out results_mimic_demo

To approach the paper's neural-network size on full authorized MIMIC-III:
    python train_mimic_cet.py --npz processed_full/mimic_demo_features.npz \\
        --n-hidden 750 --n-samples 100 --seeds 0 1 2 --out results_mimic_full

Note: fit_cet() from the supplied cet.py trains on the CPU, even if CUDA is
available. For full-scale GPU training, modify fit_cet separately.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    roc_auc_score,
)

from cet import fit_cet
from mimic_adapter_v2 import load_reconstruction, split_model_inputs


def expected_calibration_error(y: np.ndarray, p: np.ndarray, bins: int = 10) -> float:
    """Same equal-width ECE convention as the supplied experiment.py."""
    edges = np.linspace(0, 1, bins + 1)
    indices = np.clip(np.digitize(p, edges) - 1, 0, bins - 1)
    return float(sum(
        abs(y[indices == b].mean() - p[indices == b].mean()) * (indices == b).mean()
        for b in range(bins) if np.any(indices == b)
    ))


def mrae(t: np.ndarray, s: np.ndarray, predicted_t: np.ndarray) -> float | None:
    """Censoring-aware relative absolute error following the paper's evaluation.

    Observed: abs(t - prediction); censored: max(0, t - prediction).
    Divide the mean by max observed/censoring time for this event/split.
    """
    if len(t) == 0 or not (np.isfinite(t).all() and np.isfinite(predicted_t).all()):
        return None
    maximum = float(np.max(t))
    if maximum <= 0:
        return None
    absolute_error = np.where(s > 0.5, np.abs(t - predicted_t),
                              np.maximum(0, t - predicted_t))
    return float(absolute_error.mean() / maximum)


def c_index(t: np.ndarray, s: np.ndarray, predicted_t: np.ndarray) -> float | None:
    """Concordance index of predicted *times*, respecting censoring.

    Uses lifelines if installed. A simple O(n^2) fallback is provided for
    demo-sized datasets, ignoring tied observed times as ambiguous.
    """
    if not (np.isfinite(t).all() and np.isfinite(predicted_t).all()):
        return None
    try:
        from lifelines.utils import concordance_index
        score = float(concordance_index(t, predicted_t, event_observed=s))
        return score if np.isfinite(score) else None
    except ImportError:
        pass
    except ZeroDivisionError:
        return None

    if len(t) > 1500:
        print("  C-index not computed for >1500 records without lifelines. "
              "Install it with: pip install lifelines")
        return None

    comparable = correct = 0.0
    n = len(t)
    for i in range(n):
        for j in range(i + 1, n):
            if t[i] == t[j]:
                continue
            early, late = (i, j) if t[i] < t[j] else (j, i)
            if s[early] < 0.5:
                continue
            comparable += 1
            if predicted_t[early] < predicted_t[late]:
                correct += 1
            elif predicted_t[early] == predicted_t[late]:
                correct += 0.5
    return float(correct / comparable) if comparable else None


@torch.no_grad()
def predict_in_chunks(model, x: np.ndarray, seed: int, n_samples: int,
                      chunk_size: int) -> tuple[np.ndarray, np.ndarray]:
    """Return occurrence probabilities, paper-oriented event-time predictions.

    Reuses the supplied model's logits()/sample_c()/decode() interfaces.
    In contrast to its predict(), this does NOT force each c_j to 1 before
    predicting times. It takes median(exp(mu)) over occurrence draws.
    """
    model.eval()
    torch.manual_seed(seed)
    probs, predicted_times = [], []
    for start in range(0, len(x), chunk_size):
        block = torch.as_tensor(x[start:start + chunk_size], dtype=torch.float32)
        logits = model.logits(block)
        probs.append(torch.sigmoid(logits).cpu().numpy())
        occurrence_samples = model.sample_c(logits, n_samples)
        mu, _ = model.decode(block, occurrence_samples)
        # exp(mu) is the log-normal median; median over occurrence draws is
        # the original evaluation's sample aggregation convention.
        time_draws = torch.exp(mu).cpu().numpy()
        predicted_times.append(np.median(time_draws, axis=1))
    return np.concatenate(probs, axis=0), np.concatenate(predicted_times, axis=0)


def event_metrics(y_true: np.ndarray, prob: np.ndarray,
                  t: np.ndarray, s: np.ndarray,
                  predicted_t: np.ndarray) -> dict:
    """AUC undefined with one class; return JSON null rather than crashing."""
    n_pos = int((y_true > 0.5).sum())
    n = len(y_true)
    auc = float(roc_auc_score(y_true, prob)) if 0 < n_pos < n else None
    auprc = float(average_precision_score(y_true, prob)) if n_pos > 0 else None
    return {
        "n_test": n,
        "n_true_positive": n_pos,
        "n_observed_before_censor": int((s > 0.5).sum()),
        "auc": auc,
        "auprc": auprc,
        "brier": float(brier_score_loss(y_true, prob)),
        "ece": expected_calibration_error(y_true, prob),
        "mrae": mrae(t, s, predicted_t),
        "c_index": c_index(t, s, predicted_t),
    }


def check_inputs(data: dict) -> None:
    x, t, s = data["x"], data["t"], data["s"]
    c = data["c_true"]
    assert x.ndim == 2 and t.ndim == 2 and t.shape == s.shape == c.shape
    assert x.shape[0] == t.shape[0]
    assert len(data["target_names"]) == t.shape[1]
    for name in ("train", "val", "test"):
        assert (data["split"] == name).sum() > 0, f"Empty split: {name}"
    if not np.isfinite(x).all() or not np.isfinite(t).all():
        raise ValueError("Found non-finite features or censored times")
    if (t <= 0).any():
        raise ValueError("Log-normal time input requires strictly positive times")
    if not np.isin(s, [0, 1]).all() or not np.isin(c, [0, 1]).all():
        raise ValueError("Expected binary s and c_true")
    if (s > c).any():
        raise ValueError("Censoring must not create events absent from c_true")
    for column in range(t.shape[1]):
        if not (s[data["split"] == "train", column] > 0.5).any():
            print(f"WARNING: no OBSERVED training events for "
                  f"{data['target_names'][column]}; model may struggle")


def write_summary(rows: list[dict], dest: Path, n_events: int,
                  target_names: list[str]) -> None:
    lines = ["CET on preprocessed MIMIC-III data (demo = smoke test only)", ""]
    for seed in sorted({r["seed"] for r in rows}):
        lines.append(f"SEED {seed}")
        lines.append(f"{'Event':17s} {'True+':>5s} {'Obs+':>5s} {'AUC':>8s} "
                     f"{'AUPRC':>8s} {'Brier':>8s} {'ECE':>8s} {'MRAE':>8s} {'C-index':>8s}")
        for j in range(n_events):
            r = next(r for r in rows if r["seed"] == seed and r["event"] == j)
            fmt = lambda key: "N/A" if r.get(key) is None else f"{r[key]:.3f}"
            lines.append(f"{target_names[j]:17.17s} "
                         f"{r['n_true_positive']:5d} {r['n_observed_before_censor']:5d} "
                         + " ".join(f"{fmt(k):>8s}" for k in
                            ("auc", "auprc", "brier", "ece", "mrae", "c_index")))
        lines.append("")
    for key in ("auc", "auprc", "brier", "ece", "mrae", "c_index"):
        values = [r[key] for r in rows if r[key] is not None]
        lines.append(f"Mean {key} over valid seed×event entries: "
                     + (f"{np.mean(values):.4f}" if values else "N/A"))
    text = "\n".join(lines) + "\n"
    dest.write_text(text, encoding="utf-8")
    print("\n" + text)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--npz", type=Path,
                   default=Path("processed_demo/mimic_demo_features.npz"))
    p.add_argument("--out", type=Path, default=Path("results_mimic_demo"))
    p.add_argument("--seeds", type=int, nargs="+", default=[0])
    p.add_argument("--censor-seed", type=int, default=42,
                   help="Fixed across model seeds for comparable outcomes")
    p.add_argument("--censor-factor", type=float, default=2.0)
    p.add_argument("--n-hidden", type=int, default=64)
    p.add_argument("--n-samples", type=int, default=10)
    p.add_argument("--predict-samples", type=int, default=100)
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--predict-batch-size", type=int, default=256)
    p.add_argument("--max-epochs", type=int, default=30)
    p.add_argument("--patience", type=int, default=10)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--dropout", type=float, default=0.5)
    p.add_argument("--temperature", type=float, default=0.3)
    p.add_argument("--fpr", type=float, default=0.7)
    p.add_argument("--verbose", action="store_true")
    args = p.parse_args()

    if not args.npz.exists():
        p.error(f"Not found: {args.npz}. Run prepare_mimic_demo.py first.")
    if not (args.censor_factor > 0 and args.n_hidden > 0 and args.n_samples > 0
            and args.predict_samples > 0 and args.batch_size > 0
            and args.predict_batch_size > 0 and args.max_epochs > 0
            and args.patience > 0 and args.lr > 0 and 0 < args.fpr <= 1):
        p.error("Provide positive training hyperparameters and fpr in (0, 1]")
    args.out.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(min(2, torch.get_num_threads()))

    data = load_reconstruction(args.npz, factor=args.censor_factor,
                               seed=args.censor_seed)
    check_inputs(data)
    train = split_model_inputs(data, "train")
    valid = split_model_inputs(data, "val")
    x_te, t_te, s_te = split_model_inputs(data, "test")
    y_te = data["c_true"][data["split"] == "test"]
    target_names = [str(x) for x in data["target_names"]]
    M = len(target_names)

    print(f"Loaded {len(data['x'])} admissions, {data['x'].shape[1]} features, "
          f"{M} target events")
    print("Splits: train={}, validation={}, test={}".format(
        len(train[0]), len(valid[0]), len(x_te)))
    print("Training-derived censoring medians (hours):", data["censor_medians"])
    print("Train observed event counts:", train[2].sum(axis=0).astype(int))
    print("Test hidden true event counts:", y_te.sum(axis=0).astype(int))

    rows = []
    for seed in args.seeds:
        print(f"\nTraining CET seed {seed} ...", flush=True)
        model = fit_cet(
            *train, *valid,
            seed=seed,
            n_hidden=args.n_hidden,
            lr=args.lr,
            batch_size=args.batch_size,
            max_epochs=args.max_epochs,
            patience=args.patience,
            n_samples=args.n_samples,
            temperature=args.temperature,
            fpr=args.fpr,
            dropout=args.dropout,
            verbose=args.verbose,
        )
        pi, t_pred = predict_in_chunks(model, x_te, seed=seed + 10_000,
                                       n_samples=args.predict_samples,
                                       chunk_size=args.predict_batch_size)
        if not np.isfinite(pi).all() or not np.isfinite(t_pred).all():
            raise FloatingPointError("Predictions contain NaN or infinity. "
                                     "Inspect event-time units, logvar, and training learning rate.")
        for j, name in enumerate(target_names):
            row = {
                "seed": seed, "arm": "A_cet", "event": j,
                "target_name": name,
                **event_metrics(y_te[:, j], pi[:, j], t_te[:, j],
                                s_te[:, j], t_pred[:, j]),
            }
            rows.append(row)
        torch.save({
            "state_dict": model.state_dict(),
            "seed": seed,
            "n_features": int(data["x"].shape[1]),
            "n_events": M,
            "n_hidden": args.n_hidden,
            "n_samples": args.n_samples,
            "temperature": args.temperature,
            "fpr": args.fpr,
            "dropout": args.dropout,
            "target_names": target_names,
        }, args.out / f"cet_seed{seed}.pt")
        # This contains admission-level prediction/label arrays. If full MIMIC
        # is used, keep it on the authorized local environment, not in GitHub.
        np.savez_compressed(args.out / f"preds_seed{seed}.npz",
                            c=y_te, A_cet=pi, t=t_te, s=s_te,
                            predicted_time=t_pred)

    info = {"config": {
                key: str(val) if isinstance(val, Path) else val
                for key, val in vars(args).items()
            },
            "n_admissions": int(data["x"].shape[0]),
            "n_features": int(data["x"].shape[1]),
            "target_names": target_names,
            "rows": rows,
            "notes": [
                "CET only; uploaded experiment.py XGBoost arms are not run.",
                "Train/validation/test split and input scaling come from v2 preprocessing.",
                "AUC/AUPRC/Brier/ECE use uncensored occurrence labels c_true.",
                "MRAE/C-index use artificially censored test t and s.",
                "CET time predictions use sampled occurrence vectors rather than forcing c_j=1.",
                "Small demo results are not comparable to full MIMIC-III paper benchmarks.",
            ]}
    (args.out / "metrics.json").write_text(
        json.dumps(info, indent=2, allow_nan=False), encoding="utf-8")
    write_summary(rows, args.out / "summary.txt", M, target_names)
    print("Saved outputs to:", args.out.resolve())


if __name__ == "__main__":
    main()
