"""Example: use engineered demo arrays with fixed, train-derived artificial censoring.

Call after running prepare_mimic_demo.py; keep outcome truth `c_true` for EVALUATION.
Do not fit a model on hidden true occurrence in the CET reproduction.
"""
from __future__ import annotations

import argparse
import numpy as np


def censor_from_training_medians(event_time, splits, factor=2.0, seed=42):
    """Return (observed_times, observed_indicator, medians) for entire dataset.

    In contrast to the original training code, medians are estimated on the
    training split only, and censoring is fixed for reproducible testing.
    `event_time` uses np.inf for unobserved target events.
    """
    event_time = np.asarray(event_time, dtype=float)
    split = np.asarray(splits).astype(str)
    train = event_time[split == "train"]
    medians = []
    for j in range(event_time.shape[1]):
        observed = train[np.isfinite(train[:, j]), j]
        if len(observed) == 0:
            raise ValueError(f"No positive events in TRAIN for target index {j}. "
                             "Cannot estimate its censoring median; skip this event in the demo.")
        medians.append(float(np.median(observed)))
    medians = np.array(medians)
    # Allow event 0h, but use a small positive offset for log-normal likelihood.
    medians = np.maximum(medians, 0.01)
    rng = np.random.default_rng(seed)
    g = rng.uniform(size=event_time.shape) * (factor * medians) + 0.01
    s = np.isfinite(event_time) & (event_time <= g)
    t = np.minimum(np.maximum(event_time, 0.01), g)
    assert np.isfinite(t).all()
    return t.astype("float32"), s.astype("float32"), medians


def main(path):
    d = np.load(path)
    X, event_time, split = d["x"], d["event_time"], d["split"]
    t, s, medians = censor_from_training_medians(event_time, split)
    print("X:", X.shape, "t:", t.shape, "s:", s.shape)
    print("Targets:", d["target_names"].tolist())
    print("Training-median event hours:", medians)
    print("Observed positives after censoring:", s.sum(axis=0).astype(int))
    for name in ("train", "val", "test"):
        mask = split == name
        print(f"{name}: X={X[mask].shape}, t={t[mask].shape}, s={s[mask].shape}")
    # Usage in CET training: train on X, t, s -- not hidden c_true.
    # Evaluate occurrence AUC against d["c_true"] when labels are sufficient.


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--npz", default="processed_demo/mimic_demo_features.npz")
    main(p.parse_args().npz)
