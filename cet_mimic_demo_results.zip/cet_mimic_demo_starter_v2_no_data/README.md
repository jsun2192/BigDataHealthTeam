# CET MIMIC-III demo starter — revised reconstruction (v2)

**Purpose:** Reconstruct the paper's MIMIC-III first-24-hour feature/target tables without the unpublished `itemid_dict.pickle`. This is a **demonstration-scale reconstruction**, not an exact reproduction of the authors' MIMIC preprocessing. The selected ITEMIDs, aggregation choices, cohort, and outcome time origin must be documented as methodological deviations when comparing AUCs.

References: [Engelhard et al., 2020, §4.3.2](https://proceedings.mlr.press/v126/engelhard20a/engelhard20a.pdf), [reference `model_mimic.py`](https://github.com/mengelhard/cft/blob/master/src/model_mimic.py).

## Install and run

Python 3.10 or later. Install packages:

```bash
pip install -r requirements.txt
```

Place the demo CSVs in a folder, then run:

```bash
python prepare_mimic_demo.py --input "/path/to/mimic-iii-clinical-database-demo-1.4" --output processed_demo
python example_load_and_censor.py --npz processed_demo/mimic_demo_features.npz
python mimic_adapter_v2.py --npz processed_demo/mimic_demo_features.npz
python -m pytest -q test_feature_pipeline.py test_reconstruction_changes.py
```

The default selects item IDs by **raw training-set event row frequency** (a reasonable, but unverified, interpretation of "most common"); infers chart numeric type from at least 80% nonmissing `VALUENUM` in training; counts nonmissing categorical `VALUE` strings; models four outcomes; excludes **all 10** paper event labels from laboratory input candidates; and measures first outcome collection since **hospital admission**. The result may have **a different number of columns from the paper's 346**. That is intentional: we do not change which chart items are numeric merely to reproduce the published feature count.

To run the documented 346-column forced-type sensitivity experiment (assuming all 120 ITEMIDs are available):

```bash
python prepare_mimic_demo.py --input "/path/to/demo" --output processed_346 --chart-numeric-count 42
```

To rank common IDs by the number of distinct admissions containing them instead of row count:

```bash
python prepare_mimic_demo.py --input "/path/to/demo" --output processed_prevalence --rank-by admissions
```

To emulate the **literal original `create_features()` nonnumeric aggregation**, which uses `VALUENUM` even for categorical items (often null):

```bash
python prepare_mimic_demo.py --input "/path/to/demo" --output processed_reference_counts --categorical-count-mode valuenum
```

For a separate post-24-hour *next-test* prediction, use `--outcome-start landmark`. **This does not estimate time to first-ever testing** when a test occurred before 24 hours; the output deliberately means the next observed target record after the prediction landmark. An exact first-post-landmark occurrence model would exclude previously tested event-specific risk sets and modify the training mask.

For the original paper's 10 targets use `--all-ten-targets`, but note that the 100-patient demo has too few events (possibly none for some targets), making synthetic censoring medians and test AUC undefined. Use four outcomes until the full dataset is available.

## Output files

- `mimic_demo_features.npz`: `x`, `event_time` (`np.inf` when absent), `c_true`, subject/admission IDs, train/val/test split, feature names, target names.
- `selected_itemid_groups.json`: four groups with **exact keys** expected by the authors' feature loader (`chartevents_numeric`, `chartevents_nonnumeric`, `labevents`, `outputevents`), reconstructed from the demo.
- `selected_items.csv`: selected ITEMIDs and labels; audit whether feature groups make clinical sense.
- `frequency_audit.csv`: rank, raw row counts, admission prevalence, and selection flags for **all eligible observed IDs** in the training split.
- `chart_numeric_rates.csv`: per-chart-item proportion of nonmissing numeric `VALUENUM`.
- `features_raw.csv.gz`: unstandardized grouped features. No source MIMIC individual event rows are copied into the distribution ZIP.
- `feature_transform.json`: training-only medians/means/SDs and fixed feature-column order.
- `cohort.csv`: hospital admissions with an ICU stay and >=24h follow-up, grouped by subject for split.
- `metadata.json`: selection settings, selected targets, shape, cohort, missing HADM_ID records and outcome prevalence.

## Differences from the original paper and code

1. **ITEMID list is unavailable.** The 80/30/10 measurement counts and aggregations come from the paper, but the actual lists were saved in `itemid_dict.pickle`. The paper does not specify whether commonness is based on raw row counts, admissions or patients. Both ranking modes are provided; the default is raw rows, not a claim about the authors' choice.
2. **Numeric chart typing is reconstructed.** The authors' numeric/categorical membership lists are unavailable. `--chart-numeric-count 42` reproduces the implied 42 numeric + 38 categorical split, **not** the author's actual ITEMIDs.
3. **Literal original code counts categorical `VALUENUM`.** For chart items with categorical `VALUE` and null `VALUENUM`, this can produce zero counts. The default corrected `value` mode counts observed categorical strings; the `valuenum` option is available to measure the difference.
4. **Normalization:** This script fits median imputation/z-scoring once on training admissions only. The original reference `create_features` does median filling and z-scoring for each loaded batch; you can reproduce that as a dedicated methodological comparison, but train-only scaling avoids inconsistencies in predictions across different batches.
5. **Outcome time origin:** `--outcome-start admission` uses `ADMITTIME`. The reference `get_events()` takes the earliest of recorded admission, first chart and first lab timestamp. This exact intermediate dictionary (`events.pickle`) is also unavailable; for strict reproduction you would reconstruct those timestamps and handle preadmission records explicitly. `landmark` mode is intentionally a *different question*.
6. **Cohort:** One hospital admission with any ICU stay and >=24h through discharge. The paper's full cohort details and intermediate data grouping are not fully recoverable from the public repository. Only LABEVENTS with a known HADM_ID, a valid time, and in-admission record are included; missing HADM_ID records are counted but not guessed into admissions.
7. **Unit harmonization and full-data scaling:** The small pandas pipeline is appropriate for the MIMIC demo. For full MIMIC-III's large CHARTEVENTS table, use SQL/DuckDB/Polars streaming rather than reading the whole table into RAM. Audit `VALUEUOM`, `DBSOURCE`, and duplicates before scientific comparison.

## Recommended next steps

1. Run the defaults on the demo and review `selected_items.csv`, `frequency_audit.csv`, and `chart_numeric_rates.csv` by ITEMID and clinical description.
2. Compare `--rank-by rows` with `--rank-by admissions`. Record the overlap of the selected 80/30/10 sets.
3. Run `--chart-numeric-count 42` **as sensitivity**, not to claim exact replication.
4. Wait for authorized full MIMIC-III v1.4 access; reconstruct the selections on the **full training cohort**, freeze and version `selected_itemid_groups.json`, and run the same transforms on held-out data.
5. Validate outcome prevalence against the paper Table 1 before training CET/ET/BC. Record differences in population, time origin and target ITEMID aliases.
6. Connect the generated `.npz` to the PyTorch training code. Retain `c_true` solely for evaluation; apply train-derived artificial censoring to build model input `t`, `s`.

Do not upload restricted full MIMIC patient-level data or derived patient-level rows. Only share source code, aggregated summaries, and non-identifying diagnostics where permitted by your data-use agreement.

## Integration with your previous `pytorch_port_and_softlabels` files

The `mimic_adapter.py` bundled in your earlier PyTorch project says event times are measured from the end of the first 24h and computes censoring medians over all records. Both differ from this reproduction-oriented experiment. Prefer importing the new `mimic_adapter_v2.load_reconstruction()` and `split_model_inputs()`. It returns a dictionary with X, fixed censoring `t`, observed indicators `s`, and hidden `c_true`. **Never feed `c_true` to the CET loss.**

```python
from mimic_adapter_v2 import load_reconstruction, split_model_inputs
d = load_reconstruction("processed_demo/mimic_demo_features.npz", seed=42)
X_train, t_train, s_train = split_model_inputs(d, "train")
X_val, t_val, s_val = split_model_inputs(d, "val")
# Evaluate AUC against d["c_true"][d["split"] == "test"] only after fitting.
```
