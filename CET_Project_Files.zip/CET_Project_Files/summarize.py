"""Summarize results/metrics.json and run paired bootstrap tests on the saved
test-set predictions.

Usage:  python summarize.py --out results
"""

import argparse
import glob
import json
import os

import numpy as np
from sklearn.metrics import roc_auc_score, brier_score_loss

from experiment import ARMS

COMPARISONS = [("C_xgb_soft", "B_xgb_s"), ("C_xgb_soft", "A_cet"),
               ("D_xgb_soft_cetfeat", "C_xgb_soft")]


def bootstrap_diff(c, p1, p2, metric, n_boot=1000, seed=0):
    """Paired bootstrap over test patients of metric(p1) - metric(p2)."""
    rng = np.random.default_rng(seed)
    n = len(c)
    diffs = []
    for _ in range(n_boot):
        i = rng.integers(0, n, n)
        if c[i].min() == c[i].max():
            continue
        diffs.append(metric(c[i], p1[i]) - metric(c[i], p2[i]))
    d = np.array(diffs)
    return metric(c, p1) - metric(c, p2), np.percentile(d, 2.5), np.percentile(d, 97.5)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results")
    args = ap.parse_args()
    d = json.load(open(os.path.join(args.out, "metrics.json")))
    rows = d["rows"]
    seeds = sorted({r["seed"] for r in rows})
    events = sorted({r["event"] for r in rows})
    n_test = len(np.load(sorted(glob.glob(os.path.join(args.out, "preds_seed*.npz")))[0])["c"])
    lines = [f"Seeds: {seeds}   events per seed: {len(events)}   test rows per seed: {n_test}", ""]

    lines.append("Mean over events, then mean ± SD over seeds")
    lines.append(f"{'arm':22s} {'AUC':>14s} {'AUPRC':>14s} {'Brier':>14s} {'ECE':>14s}")
    for a in ARMS:
        vals = {}
        for m in ["auc", "auprc", "brier", "ece"]:
            per_seed = [np.mean([r[m] for r in rows if r["arm"] == a and r["seed"] == s])
                        for s in seeds]
            vals[m] = f"{np.mean(per_seed):.3f} ± {np.std(per_seed):.3f}"
        lines.append(f"{a:22s} " + " ".join(f"{vals[m]:>14s}" for m in vals))

    lines += ["", "Per event AUC (mean over seeds)"]
    for a in ARMS:
        lines.append(f"{a:22s} " + "  ".join(
            f"event{j}: {np.mean([r['auc'] for r in rows if r['arm'] == a and r['event'] == j]):.3f}"
            for j in events))

    lines += ["", "Soft label quality on censored TRAINING rows (out-of-fold, vs hidden true c)"]
    for s, diag in d["soft_label_diagnostics"].items():
        for g in diag:
            lines.append(
                f"seed {s} event {g['event']}: AUC {g['auc_vs_true_c']:.3f}  "
                f"mean w | c=1 {g['mean_w_true_c1']:.3f}  mean w | c=0 {g['mean_w_true_c0']:.3f}  "
                f"Brier {g['brier_vs_true_c']:.3f} (labeling all censored as 0: {g['brier_hard_zero']:.3f})")

    lines += ["", "Paired bootstrap, 1000 resamples of test patients (difference, 95% CI)"]
    for f in sorted(glob.glob(os.path.join(args.out, "preds_seed*.npz"))):
        p = np.load(f)
        c = p["c"]
        for a1, a2 in COMPARISONS:
            for j in events:
                for name, metric in [("AUC", roc_auc_score), ("Brier", brier_score_loss)]:
                    diff, lo, hi = bootstrap_diff(c[:, j], p[a1][:, j], p[a2][:, j], metric)
                    lines.append(f"{os.path.basename(f)[6:-4]:6s} event{j} {a1} − {a2} {name}: "
                                 f"{diff:+.4f} [{lo:+.4f}, {hi:+.4f}]")

    text = "\n".join(lines)
    print(text)
    with open(os.path.join(args.out, "summary.txt"), "w") as fh:
        fh.write(text + "\n")


if __name__ == "__main__":
    main()
