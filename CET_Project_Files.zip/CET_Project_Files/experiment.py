"""CET soft labels -> XGBoost, evaluated against ground-truth occurrence.

Arms (one XGBoost model per event, binary:logistic):
  A  CET alone                     pi from a CET trained on the full training split
  B  XGB raw, labels = s           the paper's BC baseline, but with XGBoost
  C  XGB raw, CET soft labels      out-of-fold posterior P(c=1 | x, t, s)
  D  XGB raw + CET features,       out-of-fold CET features (logit, mu, logvar, risk)
     CET soft labels
  O  XGB raw, labels = true c      oracle upper bound (not available in practice)

Soft labels enter XGBoost as duplicated rows: each training row appears once
with label 1 and weight w, once with label 0 and weight 1 - w.

Leakage control: soft labels and CET features for training rows come from
K-fold cross-fitting (a CET that never saw that row). Validation and test rows
use a CET fit on the full training split. Ground truth c is used ONLY for
the oracle arm and for test-set evaluation.

Usage:  python experiment.py --seeds 0 1 2 --out results
"""

import argparse
import json
import os
import time

import numpy as np
import torch
import xgboost as xgb
from scipy.stats import norm
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss
from sklearn.model_selection import KFold

from cet import fit_cet
from synthetic import generate_dataset, split

ARMS = ["A_cet", "B_xgb_s", "C_xgb_soft", "D_xgb_soft_cetfeat", "O_xgb_oracle"]


def tt(a):
    return torch.as_tensor(a, dtype=torch.float32)


# ---------------------------------------------------------------- CET outputs
def cet_features(model, x, horizon):
    """Per event: occurrence logit, mu, logvar (given c_j = 1), and risk of the
    event by `horizon`: pi * Phi((log h - mu) / sd)."""
    p = {k: v.numpy() for k, v in model.predict(tt(x)).items()}
    sd = np.exp(0.5 * p["logvar"])
    risk = p["pi"] * norm.cdf((np.log(horizon) - p["mu"]) / sd)
    return np.concatenate([p["logit"], p["mu"], p["logvar"], risk], axis=1), p["pi"]


def soft_labels(model, x, t, s):
    return model.posterior_occurrence(tt(x), tt(t), tt(s)).numpy()


def cross_fit(x, t, s, x_va, t_va, s_va, horizon, k, seed, cet_kw):
    """Out-of-fold soft labels and CET features for the training split."""
    w = np.zeros_like(s)
    feats = None
    kf = KFold(n_splits=k, shuffle=True, random_state=seed)
    for f, (fit_idx, out_idx) in enumerate(kf.split(x)):
        m = fit_cet(x[fit_idx], t[fit_idx], s[fit_idx], x_va, t_va, s_va,
                    seed=seed * 100 + f, **cet_kw)
        w[out_idx] = soft_labels(m, x[out_idx], t[out_idx], s[out_idx])
        fo, _ = cet_features(m, x[out_idx], horizon)
        if feats is None:
            feats = np.zeros((len(x), fo.shape[1]))
        feats[out_idx] = fo
        print(f"    fold {f + 1}/{k} done", flush=True)
    return w, feats


# ---------------------------------------------------------------- XGBoost
XGB_PARAMS = dict(n_estimators=2000, learning_rate=0.05, max_depth=4,
                  min_child_weight=5, subsample=0.8, tree_method="hist",
                  eval_metric="logloss", early_stopping_rounds=50, n_jobs=2)


def duplicate(X, w):
    """Soft label w in [0, 1] -> two weighted hard-label rows."""
    X2 = np.vstack([X, X])
    y2 = np.concatenate([np.ones(len(X)), np.zeros(len(X))])
    sw = np.concatenate([w, 1 - w])
    keep = sw > 0
    return X2[keep], y2[keep], sw[keep]


def fit_xgb(X_tr, y_tr, X_va, y_va, seed):
    """y may be hard (0/1) or soft (probabilities); soft labels are duplicated."""
    Xt, yt, wt = duplicate(X_tr, y_tr)
    Xv, yv, wv = duplicate(X_va, y_va)
    m = xgb.XGBClassifier(random_state=seed, **XGB_PARAMS)
    m.fit(Xt, yt, sample_weight=wt, eval_set=[(Xv, yv)],
          sample_weight_eval_set=[wv], verbose=False)
    return m


# ---------------------------------------------------------------- metrics
def ece(y, p, bins=10):
    edges = np.linspace(0, 1, bins + 1)
    idx = np.clip(np.digitize(p, edges) - 1, 0, bins - 1)
    return sum(abs(y[idx == b].mean() - p[idx == b].mean()) * (idx == b).mean()
               for b in range(bins) if (idx == b).any())


def metrics(c, p):
    return {"auc": roc_auc_score(c, p), "auprc": average_precision_score(c, p),
            "brier": brier_score_loss(c, p), "ece": ece(c, p)}


# ---------------------------------------------------------------- one seed
def run_seed(seed, args, cet_kw):
    t0 = time.time()
    x, c, t, s = generate_dataset(args.n, seed=seed, paper_rng=args.paper_rng)
    tr, va, te = split(len(x))
    mu_x, sd_x = x[tr].mean(0), x[tr].std(0)
    x = (x - mu_x) / sd_x
    M = c.shape[1]
    horizon = np.median(t[tr][s[tr] == 1])  # median observed event time

    print(f"seed {seed}: full-train CET", flush=True)
    full = fit_cet(x[tr], t[tr], s[tr], x[va], t[va], s[va], seed=seed, **cet_kw)
    f_va, _ = cet_features(full, x[va], horizon)
    f_te, pi_te = cet_features(full, x[te], horizon)
    w_va = soft_labels(full, x[va], t[va], s[va])

    print(f"seed {seed}: {args.folds}-fold cross-fitting", flush=True)
    w_tr, f_tr = cross_fit(x[tr], t[tr], s[tr], x[va], t[va], s[va],
                           horizon, args.folds, seed, cet_kw)

    preds = {a: np.zeros((len(te), M)) for a in ARMS}
    preds["A_cet"] = pi_te
    for j in range(M):
        cols = [j, M + j, 2 * M + j, 3 * M + j]  # this event's CET features
        Xd_tr = np.hstack([x[tr], f_tr[:, cols]])
        Xd_va = np.hstack([x[va], f_va[:, cols]])
        Xd_te = np.hstack([x[te], f_te[:, cols]])
        specs = {
            "B_xgb_s": (x[tr], s[tr, j], x[va], s[va, j], x[te]),
            "C_xgb_soft": (x[tr], w_tr[:, j], x[va], w_va[:, j], x[te]),
            "D_xgb_soft_cetfeat": (Xd_tr, w_tr[:, j], Xd_va, w_va[:, j], Xd_te),
            "O_xgb_oracle": (x[tr], c[tr, j], x[va], c[va, j], x[te]),
        }
        for arm, (Xa, ya, Xv, yv, Xe) in specs.items():
            m = fit_xgb(Xa, ya, Xv, yv, seed)
            preds[arm][:, j] = m.predict_proba(Xe)[:, 1]

    # soft-label quality on censored training rows (diagnostic only)
    diag = []
    for j in range(M):
        cens = s[tr, j] == 0
        cj, wj = c[tr][cens, j], w_tr[cens, j]
        diag.append({"event": j,
                     "auc_vs_true_c": roc_auc_score(cj, wj),
                     "mean_w_true_c1": float(wj[cj == 1].mean()),
                     "mean_w_true_c0": float(wj[cj == 0].mean()),
                     "brier_vs_true_c": brier_score_loss(cj, wj),
                     "brier_hard_zero": float(cj.mean())})

    rows = [{"seed": seed, "arm": a, "event": j, **metrics(c[te, j], preds[a][:, j])}
            for a in ARMS for j in range(M)]
    np.savez(os.path.join(args.out, f"preds_seed{seed}.npz"), c=c[te], **preds)
    print(f"seed {seed} finished in {(time.time() - t0) / 60:.1f} min", flush=True)
    return rows, diag


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    ap.add_argument("--n", type=int, default=40000)
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--n-samples", type=int, default=100)
    ap.add_argument("--max-epochs", type=int, default=100)
    ap.add_argument("--out", default="results")
    ap.add_argument("--paper-rng", action="store_true",
                    help="use the authors' generator, where both events share one random state")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    torch.set_num_threads(2)
    cet_kw = dict(lr=args.lr, n_samples=args.n_samples, max_epochs=args.max_epochs)

    all_rows, all_diag = [], {}
    for seed in args.seeds:
        rows, diag = run_seed(seed, args, cet_kw)
        all_rows += rows
        all_diag[seed] = diag
        with open(os.path.join(args.out, "metrics.json"), "w") as f:
            json.dump({"config": vars(args), "rows": all_rows,
                       "soft_label_diagnostics": all_diag}, f, indent=1)


if __name__ == "__main__":
    main()
