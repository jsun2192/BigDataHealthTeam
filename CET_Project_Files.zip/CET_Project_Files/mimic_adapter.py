"""Data contract for running the soft label pipeline on MIMIC-III.

Run everything here on your own machine. Do not paste MIMIC rows, extracts or
derived feature tables into a chat or any online service (PhysioNet DUA).

Your feature extraction should produce, per ICU stay:
  x           (N, d)  first-24-hour features (the paper used 346)
  event_time  (N, M)  hours from the 24 h mark to first collection of lab j,
                      np.inf if lab j never appears in the stay's full record
These come from the complete record, so the ground truth occurrence is known:
  c = np.isfinite(event_time)

The paper then censors artificially, uniformly over (0, 2 * median event time)
per lab, so CET and XGBoost train on (t, s) while evaluation uses c.
"""

import numpy as np


def artificial_censoring(event_time, seed=0):
    """Return t, s, c following Section 4.3.2 of the paper."""
    rng = np.random.default_rng(seed)
    c = np.isfinite(event_time).astype(float)
    t = np.empty_like(event_time, dtype=float)
    s = np.empty_like(event_time, dtype=float)
    for j in range(event_time.shape[1]):
        med = np.median(event_time[c[:, j] == 1, j])
        g = rng.uniform(0, 2 * med, size=len(event_time))
        t[:, j] = np.minimum(event_time[:, j], g)
        s[:, j] = (event_time[:, j] <= g).astype(float)
    return t, s, c


def load_mimic(path):
    """Expect an .npz you build locally with arrays `x` and `event_time`.
    Replace generate_dataset() in experiment.py with:
        x, event_time = load_mimic(path)
        t, s, c = artificial_censoring(event_time, seed)
    and pass n_hidden=750 to fit_cet to match the paper's MIMIC models."""
    d = np.load(path)
    return d["x"], d["event_time"]
