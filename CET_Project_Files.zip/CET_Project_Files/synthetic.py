
import numpy as np
from sklearn.datasets import make_moons, make_circles


def generate_dataset(n_samples=40000, noise=1.0, seed=0, paper_rng=False):
    rng = np.random.default_rng(seed)
    x0, c0 = make_moons(n_samples=n_samples, noise=noise, random_state=seed)
    circles_state = seed if paper_rng else seed + 10_000
    x1, c1 = make_circles(n_samples=n_samples, noise=noise, factor=.5, random_state=circles_state)
    x2 = rng.standard_normal((n_samples, 1))
    x = np.concatenate([x0, x1, x2], axis=1)
    c = np.stack([c0, c1], axis=1)
    x = x - x.mean(0)

    max_time = 3
    coeffs = np.array([[0., 0., 0., 0., 1.], [0., 0., 0., 0., -1.]]).T
    mu_event = x @ coeffs + .3
    sig_event = .25 * rng.standard_normal((n_samples, 2))
    event_times = np.exp(mu_event + sig_event * rng.standard_normal((n_samples, 2))) + max_time * (1 - c)
    censor_times = max_time * rng.random((n_samples, 2))

    t = np.minimum(event_times, censor_times)
    s = (t == event_times).astype(float)

    perm = rng.permutation(n_samples)
    return x[perm], c[perm].astype(float), t[perm], s[perm]


def split(n, fractions=(.6, .2, .2)):
    a = int(fractions[0] * n)
    b = int((fractions[0] + fractions[1]) * n)
    idx = np.arange(n)
    return idx[:a], idx[a:b], idx[b:]
