# Data

synthetic_corrected.csv       40,000 rows, seed 0, independent random states for moons and circles (used for all reported results)
synthetic_paper_original.csv  same, but reproducing the authors' generator, where both events share a random state (events identical, noise cancels)

Columns: x0-x4 features; t1,t2 observed times; s1,s2 1 if event observed (0 = censored); c1,c2 true occurrence (hidden in real data, use only for evaluation or the oracle); split = train/val/test (60/20/20).

NOT included: MIMIC-III (credentialed via PhysioNet; see mimic_adapter.py) and Reddit (Pushshift access was revoked in 2023).
