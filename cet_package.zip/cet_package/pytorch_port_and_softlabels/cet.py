"""PyTorch port of the Conditional Event Time (CET) model.

Follows the authors' TensorFlow code (github.com/mengelhard/cft, src/model.py):
  * encoder:  x -> one hidden layer -> M occurrence logits
  * decoder:  [x, c] -> one shared hidden layer -> two heads (mu, logvar), M each
  * c is a Gumbel-Softmax (binary Concrete) relaxation, temperature 0.3, 100 samples
  * loss per event j (fpr_likelihood=True, prop_fpr=True in the original):
        s * [-log f(t)]  +  (1 - s) * c * [-log F(t)]  +  s * (1 - c) * [-log(fpr * pi)]
    where f, F are the log-normal density and survivor function of the event time.

Note: the paper writes nu = exp(NN) as the standard deviation; the code actually
predicts a log variance, so sd = exp(0.5 * logvar). We follow the code.
"""

import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

LOG_EPS = 1e-4  # matches the original's log(t + 1e-4)


def mlp(n_in, n_hidden, dropout):
    return nn.Sequential(nn.Linear(n_in, n_hidden), nn.ReLU(), nn.Dropout(dropout))


class CET(nn.Module):
    def __init__(self, n_features, n_events, n_hidden=100, dropout=0.5,
                 n_samples=100, temperature=0.3, fpr=0.7):
        super().__init__()
        self.M = n_events
        self.n_samples = n_samples
        self.temperature = temperature
        self.nlog_fpr = -math.log(fpr)
        self.enc = mlp(n_features, n_hidden, dropout)
        self.enc_out = nn.Linear(n_hidden, n_events)
        self.dec = mlp(n_features + n_events, n_hidden, dropout)
        self.mu_head = nn.Linear(n_hidden, n_events)
        self.logvar_head = nn.Linear(n_hidden, n_events)

    # ---- building blocks -------------------------------------------------
    def logits(self, x):
        return self.enc_out(self.enc(x))

    def sample_c(self, logits, n_samples):
        """Binary Concrete samples, shape (N, S, M). One logistic noise draw per
        sample index shared across rows and events, as in the original code."""
        u1 = torch.rand(n_samples, device=logits.device).clamp(1e-10, 1 - 1e-10)
        u2 = torch.rand(n_samples, device=logits.device).clamp(1e-10, 1 - 1e-10)
        g = -torch.log(-torch.log(u1)) + torch.log(-torch.log(u2))  # Gumbel - Gumbel = logistic
        y = logits[:, None, :] + g[None, :, None]
        return torch.sigmoid(y / self.temperature)

    def decode(self, x, c):
        """x: (N, d); c: (N, S, M) -> mu, logvar: (N, S, M)."""
        xs = x[:, None, :].expand(-1, c.shape[1], -1)
        h = self.dec(torch.cat([xs, c], dim=-1))
        return self.mu_head(h), self.logvar_head(h)

    @property
    def device(self):
        return next(self.parameters()).device

    # ---- likelihood ------------------------------------------------------
    @staticmethod
    def lognormal_terms(t, mu, logvar):
        """-log f(t) and -log F(t) for a log-normal, broadcasting t to mu."""
        logt = torch.log(t + LOG_EPS)
        sd = torch.exp(0.5 * logvar)
        z = (logt - mu) / sd
        nlogpdf = logt + torch.log(sd) + 0.5 * z ** 2 + 0.5 * math.log(2 * math.pi)
        # log survival = log(1 - Phi(z)), computed stably
        nlogsurv = -torch.special.log_ndtr(-z)
        return nlogpdf, nlogsurv

    def nll(self, x, t, s):
        logits = self.logits(x)
        c = self.sample_c(logits, self.n_samples)          # (N, S, M)
        mu, logvar = self.decode(x, c)
        tt, ss = t[:, None, :], s[:, None, :]
        nlogp, nlogs = self.lognormal_terms(tt, mu, logvar)
        nlog_fpr = (self.nlog_fpr - F.logsigmoid(logits))[:, None, :]
        loss = ss * nlogp + (1 - ss) * c * nlogs + ss * (1 - c) * nlog_fpr
        return loss.mean()

    @torch.no_grad()
    def dataset_nll(self, x, t, s, chunk=2048):
        """Mean NLL over a whole dataset, evaluated in chunks so memory stays flat
        (each row expands to n_samples x hidden activations)."""
        self.eval()
        total, n = 0.0, 0
        for i in range(0, len(x), chunk):
            xb, tb, sb = (a[i:i + chunk].to(self.device) for a in (x, t, s))
            total += self.nll(xb, tb, sb).item() * len(xb)
            n += len(xb)
        return total / n

    # ---- outputs used downstream -----------------------------------------
    @torch.no_grad()
    def predict(self, x, n_samples=100, chunk=2048):
        """Occurrence probabilities plus, for each event j, mu/logvar of the
        event time GIVEN c_j = 1 (other events averaged over sampled c).
        Accepts tensors on any device; returns CPU tensors."""
        self.eval()
        outs = [self._predict_chunk(x[i:i + chunk].to(self.device), n_samples)
                for i in range(0, len(x), chunk)]
        return {k: torch.cat([o[k] for o in outs]).cpu() for k in outs[0]}

    def _predict_chunk(self, x, n_samples):
        logits = self.logits(x)
        c = self.sample_c(logits, n_samples)
        mu_j, lv_j = [], []
        for j in range(self.M):
            cj = c.clone()
            cj[..., j] = 1.0
            mu, lv = self.decode(x, cj)
            mu_j.append(mu[..., j].mean(1))
            lv_j.append(lv[..., j].mean(1))
        return {
            "logit": logits,
            "pi": torch.sigmoid(logits),
            "mu": torch.stack(mu_j, 1),
            "logvar": torch.stack(lv_j, 1),
        }

    @torch.no_grad()
    def posterior_occurrence(self, x, t, s, n_samples=100, chunk=2048):
        """Soft label P(c_j = 1 | x, t_j, s_j) for every event.

        Observed event (s=1): 1.
        Censored at t (s=0):  pi * S(t) / (pi * S(t) + 1 - pi),
        where S(t) is the conditional survivor function given c_j = 1,
        averaged over samples of the other events' c.
        Accepts tensors on any device; returns a CPU tensor.
        """
        self.eval()
        outs = [self._posterior_chunk(*(a[i:i + chunk].to(self.device) for a in (x, t, s)),
                                      n_samples)
                for i in range(0, len(x), chunk)]
        return torch.cat(outs).cpu()

    def _posterior_chunk(self, x, t, s, n_samples):
        logits = self.logits(x)
        pi = torch.sigmoid(logits)
        c = self.sample_c(logits, n_samples)
        surv = []
        for j in range(self.M):
            cj = c.clone()
            cj[..., j] = 1.0
            mu, lv = self.decode(x, cj)
            _, nlogs = self.lognormal_terms(t[:, None, j], mu[..., j], lv[..., j])
            surv.append(torch.exp(-nlogs).mean(1))
        S = torch.stack(surv, 1)
        w_cens = pi * S / (pi * S + (1 - pi))
        return torch.where(s > 0.5, torch.ones_like(w_cens), w_cens)


def fit_cet(x_tr, t_tr, s_tr, x_va, t_va, s_va, seed=0, n_hidden=100,
            lr=3e-4, batch_size=400, max_epochs=100, patience=10, verbose=False,
            device="cpu", **kw):
    """Adam + early stopping on validation NLL, as in the original.
    device: "cpu", "cuda" or "cuda:0". The returned model stays on that device;
    predict() and posterior_occurrence() return CPU tensors."""
    device = torch.device(device)
    if device.type == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("device='cuda' requested but CUDA is not available")
        torch.backends.cuda.matmul.allow_tf32 = True   # faster matmuls on Ampere/Ada GPUs
        torch.backends.cudnn.allow_tf32 = True
    torch.manual_seed(seed)
    np.random.seed(seed)
    to = lambda a: torch.as_tensor(a, dtype=torch.float32, device=device)
    Xtr, Ttr, Str = to(x_tr), to(t_tr), to(s_tr)
    Xva, Tva, Sva = to(x_va), to(t_va), to(s_va)
    model = CET(Xtr.shape[1], Ttr.shape[1], n_hidden=n_hidden, **kw).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    best, best_state, bad = np.inf, None, 0
    n = len(Xtr)
    for epoch in range(max_epochs):
        model.train()
        perm = torch.randperm(n, device=device)
        for i in range(0, n, batch_size):
            idx = perm[i:i + batch_size]
            loss = model.nll(Xtr[idx], Ttr[idx], Str[idx])
            opt.zero_grad()
            loss.backward()
            opt.step()
        v = model.dataset_nll(Xva, Tva, Sva)
        if verbose and epoch % 10 == 0:
            print(f"epoch {epoch:3d}  val nll {v:.4f}")
        if v < best - 1e-5:
            best, bad = v, 0
            best_state = {k: p.clone() for k, p in model.state_dict().items()}
        else:
            bad += 1
            if bad > patience:
                break
    if best_state is None:
        raise RuntimeError("validation NLL never improved (NaN or diverged); "
                           "try a smaller --lr or check for NaN/inf in the inputs")
    model.load_state_dict(best_state)
    model.eval()
    return model
