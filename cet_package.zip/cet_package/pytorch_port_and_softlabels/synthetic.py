"""Synthetic data from the paper, copied from generate_dataset() in the
authors' src/model.py, with a seed argument added.

Event 1 occurrence: make_moons on features 0-1.
Event 2 occurrence: make_circles on features 2-3.
Timing of both events: feature 4 (log-time mean +x4 and -x4, plus 0.3).
Events with c = 0 get times beyond the maximum censoring time (3), so they are
never observed. Censoring is Uniform(0, 3) and independent of everything.
"""

import numpy as np
from sklearn.datasets import make_moons, make_circles


def generate_dataset(n_samples=40000, noise=1.0, seed=0, paper_rng=False):
    """paper_rng=True reproduces the authors' generator exactly, which passes the
    SAME random_state to make_moons and make_circles. Both functions then draw
    the same shuffle and the same noise, so:
      * c (event 1) and c (event 2) are identical for every row, and
      * the Gaussian noise cancels in (moons features - circles features),
        so the true occurrence is almost perfectly recoverable from x.
    The default (False) gives the two generators independent random states."""
    rng = np.random.default_rng(seed)
    x0, c0 = make_moons(n_samples=n_samples, noise=noise, random_state=seed)
    circles_state = seed if paper_rng else seed + 10_000
    x1, c1 = make_circles(n_samples=n_samples, noise=noise, factor=.5, random_state=circles_state)
    x2 = rng.standard_normal((n_samples, 1))
    x = np.concatenate([x0, x1, x2], axis=1)
    c = np.stack([c0, c1], axis=1)
    x = x - x.mean(0)

    max_time = 3
    coeffs = np.array([[0., 0., 0., 0., 1.], [0., 0., 0., 0., -1.]]).T
    mu_event = x @ coeffs + .3
    sig_event = .25 * rng.standard_normal((n_samples, 2))
    event_times = np.exp(mu_event + sig_event * rng.standard_normal((n_samples, 2))) + max_time * (1 - c)
    censor_times = max_time * rng.random((n_samples, 2))

    t = np.minimum(event_times, censor_times)
    s = (t == event_times).astype(float)

    # extra shuffle so the 60/20/20 split does not depend on generator ordering
    perm = rng.permutation(n_samples)
    return x[perm], c[perm].astype(float), t[perm], s[perm]


def split(n, fractions=(.6, .2, .2)):
    a = int(fractions[0] * n)
    b = int((fractions[0] + fractions[1]) * n)
    idx = np.arange(n)
    return idx[:a], idx[a:b], idx[b:]
