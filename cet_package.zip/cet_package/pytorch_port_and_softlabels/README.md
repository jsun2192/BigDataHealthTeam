# CET soft labels for XGBoost

Train a Conditional Event Time (CET) model (Engelhard et al., MLHC 2020), use it to turn
right-censored records into soft occurrence labels, and train XGBoost on those labels.
Evaluated against hidden ground-truth occurrence on the paper's synthetic task.

## Files

| File | Purpose |
|---|---|
| `cet.py` | PyTorch port of the authors' TensorFlow CET (`mengelhard/cft`, `src/model.py`), plus `posterior_occurrence()` for soft labels |
| `synthetic.py` | The paper's synthetic generator, with the shared random-state bug fixed (`paper_rng=True` reproduces the original) |
| `experiment.py` | Cross-fitted soft labels, five comparison arms, metrics vs. true occurrence |
| `summarize.py` | Results table, soft label diagnostics, paired bootstrap tests |
| `mimic_adapter.py` | Data contract and artificial censoring for running on MIMIC-III locally |
| `results/` | 3-seed run on the corrected generator (`summary.txt`, `metrics.json`, test predictions) |
| `results_paper_generator_seed0/` | 1 seed on the original, leaky generator, for comparison |

## How the soft labels work

For event j and a censored row (s = 0 at time t):

    w = pi * S(t) / (pi * S(t) + 1 - pi)

where pi is CET's occurrence probability and S(t) is the probability the event has not
happened yet by t, given that it will happen. Observed events get w = 1. Each training row
enters XGBoost twice: label 1 with weight w and label 0 with weight 1 - w.

Soft labels and CET features for training rows are cross-fitted (5 folds), so no row is
labeled by a CET that trained on it.

## Arms

| Arm | Model | Labels |
|---|---|---|
| A | CET alone | censored times |
| B | XGBoost, raw features | s (observed or not); the paper's BC baseline |
| C | XGBoost, raw features | CET soft labels |
| D | XGBoost, raw + CET features (logit, mu, logvar, risk by median time) | CET soft labels |
| O | XGBoost, raw features | true c (oracle ceiling, not available in practice) |

## Results (corrected generator, 3 seeds, 8,000 test rows each)

| Arm | AUC | AUPRC | Brier | ECE |
|---|---|---|---|---|
| A CET | 0.668 ± 0.002 | 0.657 ± 0.004 | 0.228 ± 0.001 | 0.078 ± 0.002 |
| B XGB on s | 0.576 ± 0.002 | 0.591 ± 0.003 | 0.323 ± 0.001 | 0.261 ± 0.003 |
| C XGB soft | 0.667 ± 0.007 | 0.653 ± 0.008 | 0.234 ± 0.001 | 0.106 ± 0.005 |
| D XGB soft + CET feats | 0.667 ± 0.002 | 0.655 ± 0.003 | 0.234 ± 0.000 | 0.105 ± 0.003 |
| O oracle | 0.682 ± 0.002 | 0.665 ± 0.005 | 0.217 ± 0.001 | 0.015 ± 0.001 |

Averaged over the two events. Event 1 (circles, noise 1) is close to unlearnable: the oracle
reaches only 0.578 AUC on it. Full per-event results and bootstrap intervals are in
`results/summary.txt`.

## Deviations from the paper

- CET training used learning rate 1e-3 and 30 Gumbel-Softmax samples (paper: 3e-4 and 100) to
  fit 18 CET models on 2 CPU cores. A check on the original generator with these settings gave
  CET test AUC 0.93 and 0.97, matching Table 3.
- The synthetic generator uses independent random states for moons and circles (see below).
- Features are standardized with training split statistics.

## Bug in the original synthetic generator

`generate_dataset()` in the authors' code passes `random_state=0` to both `make_moons` and
`make_circles`. Both functions then draw the same shuffle and the same noise, so the two
events have identical occurrence labels for every row, and the noise cancels when the
moons features are subtracted from the circles features. Run `python -c "from sklearn.datasets
import make_moons, make_circles; print((make_moons(40000, noise=1., random_state=0)[1] ==
make_circles(40000, noise=1., factor=.5, random_state=0)[1]).mean())"` to see 1.0.

## Running

    pip install torch xgboost scikit-learn scipy
    python experiment.py --seeds 0 1 2 --lr 1e-3 --n-samples 30 --out results
    python summarize.py --out results

About 5 to 7 minutes per seed on 2 CPU cores.

GPU: `--device auto` (default) uses CUDA when PyTorch can see it, otherwise CPU. Force it with
`--device cuda`, add `--xgb-gpu` to train XGBoost on the GPU, and use `--n-hidden 750` for the
paper's MIMIC width. Install a CUDA build of PyTorch from pytorch.org. Example:

    python experiment.py --seeds 0 --device cuda --xgb-gpu --n-hidden 750 --n-samples 100 --lr 3e-4

Evaluation runs in chunks of 2,048 rows, so memory stays flat on large datasets. CUDA was not
available in the workspace where this was written, so the GPU path is untested; the CPU path is
tested. For MIMIC-III, see `mimic_adapter.py`, use
`n_hidden=750`, and keep all data on your own machine.
